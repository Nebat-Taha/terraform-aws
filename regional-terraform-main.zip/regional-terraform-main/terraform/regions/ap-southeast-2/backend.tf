terraform {
  backend "s3" {
    bucket         = "nebat" # Replace with your bucket name
    key            = "regional-terraform-state/ap-southeast-2/terraform.tfstate"
    region         = "us-east-1" # Replace with your preferred region
    encrypt        = true
    dynamodb_table = "terraform-state-locking"

  }
}